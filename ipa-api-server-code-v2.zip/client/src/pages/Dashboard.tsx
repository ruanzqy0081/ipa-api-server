import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Box,
  Clock,
  Key,
  Smartphone,
  TrendingUp,
  Users,
  Zap,
  AlertTriangle,
} from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const mockChartData = [
  { name: "Seg", keys: 12, devices: 4 },
  { name: "Ter", keys: 19, devices: 6 },
  { name: "Qua", keys: 8, devices: 3 },
  { name: "Qui", keys: 25, devices: 9 },
  { name: "Sex", keys: 17, devices: 5 },
  { name: "Sáb", keys: 30, devices: 12 },
  { name: "Dom", keys: 22, devices: 8 },
];

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  const { data: expiringKeys } = trpc.dashboard.expiringKeys.useQuery();

  const statCards = [
    {
      title: "Total de Packages",
      value: stats?.totalPackages ?? 0,
      icon: Box,
      color: "text-violet-400",
      bg: "bg-violet-400/10",
      trend: "+2 este mês",
    },
    {
      title: "Keys Ativas",
      value: stats?.activeKeys ?? 0,
      icon: Key,
      color: "text-emerald-400",
      bg: "bg-emerald-400/10",
      trend: "Em uso agora",
    },
    {
      title: "Devices Registrados",
      value: stats?.totalDevices ?? 0,
      icon: Smartphone,
      color: "text-blue-400",
      bg: "bg-blue-400/10",
      trend: "Total cadastrado",
    },
    {
      title: "Usuários VIP",
      value: stats?.totalVipUsers ?? 0,
      icon: Users,
      color: "text-amber-400",
      bg: "bg-amber-400/10",
      trend: "Assinantes ativos",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            Bem-vindo, <span className="gradient-text">{user?.name?.split(" ")[0] ?? "Admin"}</span>
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Visão geral do seu sistema API Server Manager
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-muted-foreground">Sistema Online</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <Card key={card.title} className="card-hover border-border/50 bg-card/50">
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
                    {card.title}
                  </p>
                  <p className="text-3xl font-bold mt-2 text-foreground">
                    {isLoading ? (
                      <span className="inline-block h-8 w-16 bg-muted animate-pulse rounded" />
                    ) : (
                      card.value.toLocaleString()
                    )}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    {card.trend}
                  </p>
                </div>
                <div className={`h-10 w-10 rounded-xl ${card.bg} flex items-center justify-center`}>
                  <card.icon className={`h-5 w-5 ${card.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Chart + Expiring Keys */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Chart */}
        <Card className="lg:col-span-2 border-border/50 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Zap className="h-4 w-4 text-primary" />
              Atividade Semanal
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={mockChartData}>
                <defs>
                  <linearGradient id="keysGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.62 0.22 280)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.62 0.22 280)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="devicesGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.65 0.18 200)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.018 260)" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "oklch(0.55 0.01 260)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.01 260)" }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: "oklch(0.14 0.018 260)", border: "1px solid oklch(0.22 0.018 260)", borderRadius: "8px", fontSize: "12px" }}
                  labelStyle={{ color: "oklch(0.95 0.005 260)" }}
                />
                <Area type="monotone" dataKey="keys" stroke="oklch(0.62 0.22 280)" fill="url(#keysGrad)" strokeWidth={2} name="Keys" />
                <Area type="monotone" dataKey="devices" stroke="oklch(0.65 0.18 200)" fill="url(#devicesGrad)" strokeWidth={2} name="Devices" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Expiring Keys */}
        <Card className="border-border/50 bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-400" />
              Keys Expirando (24h)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!expiringKeys || expiringKeys.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-32 text-center">
                <div className="h-10 w-10 rounded-full bg-emerald-400/10 flex items-center justify-center mb-3">
                  <Key className="h-5 w-5 text-emerald-400" />
                </div>
                <p className="text-sm text-muted-foreground">Nenhuma key expirando</p>
                <p className="text-xs text-muted-foreground/60 mt-1">Tudo em ordem!</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {expiringKeys.map((key) => (
                  <div key={key.id} className="flex items-center justify-between p-2 rounded-lg bg-amber-400/5 border border-amber-400/20">
                    <div className="min-w-0">
                      <p className="text-xs font-mono truncate text-foreground">{key.keyValue.slice(0, 20)}...</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                        <Clock className="h-3 w-3" />
                        {key.expiresAt ? new Date(key.expiresAt).toLocaleString("pt-BR") : "—"}
                      </p>
                    </div>
                    <Badge className="status-paused text-xs shrink-0 ml-2">Expirando</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold">Ações Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: "Novo Package", icon: Box, path: "/packages", color: "text-violet-400", bg: "bg-violet-400/10" },
              { label: "Gerar Keys", icon: Key, path: "/keys", color: "text-emerald-400", bg: "bg-emerald-400/10" },
              { label: "Build Dylib", icon: Zap, path: "/dylib", color: "text-primary", bg: "bg-primary/10" },
              { label: "Ver Devices", icon: Smartphone, path: "/devices", color: "text-blue-400", bg: "bg-blue-400/10" },
            ].map((action) => (
              <a
                key={action.label}
                href={action.path}
                className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border/50 hover:border-primary/30 hover:bg-accent/30 transition-all cursor-pointer group"
              >
                <div className={`h-10 w-10 rounded-xl ${action.bg} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <action.icon className={`h-5 w-5 ${action.color}`} />
                </div>
                <span className="text-xs font-medium text-center text-muted-foreground group-hover:text-foreground transition-colors">
                  {action.label}
                </span>
              </a>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
