import { PageHeader, PageHeaderDescription, PageHeaderHeading } from "@/components/page-header";

export default function Settings() {
  return (
    <div className="container">
      <PageHeader>
        <PageHeaderHeading>Configurações</PageHeaderHeading>
        <PageHeaderDescription>
          Gerencie as configurações gerais do seu IPA API Server.
        </PageHeaderDescription>
      </PageHeader>
      <div className="grid gap-6">
        {/* Adicione seus componentes de configuração aqui */}
        <p>Conteúdo das configurações...</p>
      </div>
    </div>
  );
}
