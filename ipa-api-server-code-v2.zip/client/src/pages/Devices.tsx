import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Ban, Clock, MoreVertical, Plus, RefreshCw, Smartphone, Trash2, Wifi, WifiOff } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Devices() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const { data: devices, isLoading } = trpc.devices.list.useQuery();
  const registerMut = trpc.devices.register.useMutation({ onSuccess: () => { utils.devices.list.invalidate(); toast.success("Device registrado!"); setShowRegister(false); setForm({ udid: "", name: "" }); } });
  const updateMut = trpc.devices.update.useMutation({ onSuccess: () => { utils.devices.list.invalidate(); toast.success("Device atualizado!"); setEditDevice(null); } });
  const deleteMut = trpc.devices.delete.useMutation({ onSuccess: () => { utils.devices.list.invalidate(); toast.success("Device removido!"); } });
  const banMut = trpc.devices.ban.useMutation({ onSuccess: () => { utils.devices.list.invalidate(); toast.success("Device banido!"); } });

  const [showRegister, setShowRegister] = useState(false);
  const [editDevice, setEditDevice] = useState<NonNullable<typeof devices>[0] | null>(null);
  const [form, setForm] = useState({ udid: "", name: "" });
  const isAdmin = user?.role === "admin";

  const statusIcon = (status: string) => {
    if (status === "online") return <Wifi className="h-3.5 w-3.5 text-emerald-400" />;
    if (status === "banned") return <Ban className="h-3.5 w-3.5 text-red-500" />;
    return <WifiOff className="h-3.5 w-3.5 text-slate-400" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Devices / UDIDs</h1>
          <p className="text-sm text-muted-foreground mt-1">Gerencie dispositivos registrados no sistema</p>
        </div>
        <Button onClick={() => setShowRegister(true)} className="gap-2">
          <Plus className="h-4 w-4" /> Registrar Device
        </Button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Total", value: devices?.length ?? 0, color: "text-foreground" },
          { label: "Online", value: devices?.filter((d) => d.status === "online").length ?? 0, color: "text-emerald-400" },
          { label: "Banidos", value: devices?.filter((d) => d.status === "banned").length ?? 0, color: "text-red-400" },
        ].map((s) => (
          <Card key={s.label} className="border-border/50 bg-card/50">
            <CardContent className="p-4 text-center">
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/50 bg-card/50">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Carregando...</div>
          ) : !devices?.length ? (
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Smartphone className="h-8 w-8 text-primary" />
              </div>
              <div className="text-center">
                <p className="font-semibold">Nenhum device registrado</p>
                <p className="text-sm text-muted-foreground mt-1">Registre o primeiro dispositivo</p>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50 hover:bg-transparent">
                    <TableHead className="text-xs text-muted-foreground">Dispositivo</TableHead>
                    <TableHead className="text-xs text-muted-foreground">UDID</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Status</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Último acesso</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Registrado em</TableHead>
                    <TableHead className="text-xs text-muted-foreground w-10" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {devices.map((device) => (
                    <TableRow key={device.id} className="border-border/30 hover:bg-accent/20">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-lg bg-muted/50 flex items-center justify-center shrink-0">
                            <Smartphone className="h-4 w-4 text-muted-foreground" />
                          </div>
                          <span className="text-sm font-medium">{device.name || "Sem nome"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <code className="text-xs font-mono text-muted-foreground max-w-[180px] truncate block">{device.udid}</code>
                      </TableCell>
                      <TableCell>
                        <Badge className={`status-${device.status} text-xs flex items-center gap-1 w-fit`}>
                          {statusIcon(device.status)}
                          {device.status === "online" ? "Online" : device.status === "banned" ? "Banido" : "Offline"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {device.lastSeen ? (
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {new Date(device.lastSeen).toLocaleString("pt-BR")}
                          </span>
                        ) : "—"}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {new Date(device.createdAt).toLocaleDateString("pt-BR")}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7">
                              <MoreVertical className="h-3.5 w-3.5" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setEditDevice(device)}>
                              <RefreshCw className="mr-2 h-4 w-4" /> Editar
                            </DropdownMenuItem>
                            {isAdmin && device.status !== "banned" && (
                              <DropdownMenuItem onClick={() => banMut.mutate({ id: device.id })} className="text-amber-500 focus:text-amber-500">
                                <Ban className="mr-2 h-4 w-4" /> Banir
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => { if (confirm("Remover este device?")) deleteMut.mutate({ id: device.id }); }}
                            >
                              <Trash2 className="mr-2 h-4 w-4" /> Remover
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Register Dialog */}
      <Dialog open={showRegister} onOpenChange={setShowRegister}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Smartphone className="h-5 w-5 text-primary" /> Registrar Device</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>UDID *</Label>
              <Input placeholder="00008030-001234567890ABCD" value={form.udid} onChange={(e) => setForm({ ...form, udid: e.target.value })} className="font-mono text-sm" />
              <p className="text-xs text-muted-foreground">O UDID único do dispositivo iOS</p>
            </div>
            <div className="space-y-1.5">
              <Label>Nome do dispositivo</Label>
              <Input placeholder="iPhone do João" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRegister(false)}>Cancelar</Button>
            <Button onClick={() => registerMut.mutate(form)} disabled={!form.udid || registerMut.isPending} className="gap-2">
              {registerMut.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Registrar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      {editDevice && (
        <Dialog open={!!editDevice} onOpenChange={() => setEditDevice(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Device</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Nome</Label>
                <Input value={editDevice.name ?? ""} onChange={(e) => setEditDevice({ ...editDevice, name: e.target.value })} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDevice(null)}>Cancelar</Button>
              <Button onClick={() => updateMut.mutate({ id: editDevice.id, name: editDevice.name ?? undefined })} disabled={updateMut.isPending}>
                Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
