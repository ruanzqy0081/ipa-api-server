import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Download, FileCode2, History, Package, RefreshCw, Zap } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

export default function DylibBuilder() {
  const utils = trpc.useUtils();
  const { data: packages } = trpc.packages.list.useQuery();
  const [selectedPackage, setSelectedPackage] = useState("");
  const [version, setVersion] = useState("1.0.0");
  const { data: history } = trpc.dylib.history.useQuery({});
  const generateMut = trpc.dylib.generate.useMutation({
    onSuccess: (data) => {
      utils.dylib.history.invalidate();
      toast.success("Dylib gerada com sucesso!", {
        description: data.fileName,
        action: {
          label: "Download",
          onClick: () => window.open(data.downloadUrl, "_blank"),
        },
      });
    },
    onError: (err) => toast.error("Erro ao gerar dylib", { description: err.message }),
  });

  const selectedPkg = packages?.find((p) => String(p.id) === selectedPackage);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Build Dylib</h1>
        <p className="text-sm text-muted-foreground mt-1">Gere arquivos dylib com o token do package integrado</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Builder */}
        <Card className="border-border/50 bg-card/50">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" /> Gerar Nova Dylib
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-1.5">
              <Label>Package *</Label>
              <Select value={selectedPackage} onValueChange={setSelectedPackage}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um package" />
                </SelectTrigger>
                <SelectContent>
                  {packages?.filter((p) => p.status === "active").map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      <div className="flex items-center gap-2">
                        <Package className="h-3.5 w-3.5 text-muted-foreground" />
                        {p.name} <span className="text-muted-foreground text-xs">v{p.version}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Versão da Dylib</Label>
              <Input value={version} onChange={(e) => setVersion(e.target.value)} placeholder="1.0.0" />
            </div>

            {selectedPkg && (
              <div className="rounded-xl bg-muted/30 border border-border/50 p-4 space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Detalhes do Package</p>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Nome</span>
                    <span className="font-medium">{selectedPkg.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Versão</span>
                    <span className="font-medium">v{selectedPkg.version}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Status</span>
                    <Badge className="status-active text-xs">Ativo</Badge>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-xs text-muted-foreground">Token</span>
                    <code className="text-xs font-mono bg-muted/50 rounded px-2 py-1 break-all">{selectedPkg.token}</code>
                  </div>
                </div>
              </div>
            )}

            <div className="rounded-xl bg-primary/5 border border-primary/20 p-4">
              <p className="text-xs font-semibold text-primary mb-2">O que será gerado:</p>
              <ul className="text-xs text-muted-foreground space-y-1.5">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  Arquivo <code className="bg-muted px-1 rounded">.dylib</code> com token integrado
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  SDK de autenticação com Get UDID e validação de Key
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  Armazenado no S3 com URL de download segura
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-0.5">•</span>
                  Histórico de versões mantido
                </li>
              </ul>
            </div>

            <Button
              className="w-full gap-2 glow-primary"
              onClick={() => generateMut.mutate({ packageId: Number(selectedPackage), version })}
              disabled={!selectedPackage || generateMut.isPending}
              size="lg"
            >
              {generateMut.isPending ? (
                <><RefreshCw className="h-4 w-4 animate-spin" /> Gerando Dylib...</>
              ) : (
                <><Zap className="h-4 w-4" /> Gerar Dylib</>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="border-border/50 bg-card/50">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <FileCode2 className="h-5 w-5 text-primary" /> Como Usar a Dylib
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { step: "1", title: "Gere a Dylib", desc: "Selecione o package e clique em Gerar. O arquivo será criado com o token integrado automaticamente." },
              { step: "2", title: "Baixe o arquivo", desc: "Após a geração, faça o download do arquivo .dylib pelo link disponível no histórico." },
              { step: "3", title: "Injete no IPA", desc: "Use uma ferramenta de injeção de dylib (ex: Sideloadly, AltStore) para inserir o arquivo no seu IPA." },
              { step: "4", title: "Fluxo no app", desc: "Ao abrir o app, o SDK solicitará o UDID do dispositivo, registrará o device e exibirá a tela de login com Key." },
            ].map((item) => (
              <div key={item.step} className="flex gap-3">
                <div className="h-7 w-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0 mt-0.5">
                  {item.step}
                </div>
                <div>
                  <p className="text-sm font-semibold">{item.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* History */}
      <Card className="border-border/50 bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <History className="h-4 w-4 text-primary" />
            Histórico de Builds ({history?.length ?? 0})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {!history?.length ? (
            <div className="flex flex-col items-center justify-center py-10 gap-3">
              <FileCode2 className="h-10 w-10 text-muted-foreground/30" />
              <p className="text-sm text-muted-foreground">Nenhuma dylib gerada ainda</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50 hover:bg-transparent">
                    <TableHead className="text-xs text-muted-foreground">Arquivo</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Versão</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Tamanho</TableHead>
                    <TableHead className="text-xs text-muted-foreground">Gerado em</TableHead>
                    <TableHead className="text-xs text-muted-foreground w-20">Download</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {history.map((build) => (
                    <TableRow key={build.id} className="border-border/30 hover:bg-accent/20">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileCode2 className="h-4 w-4 text-primary shrink-0" />
                          <span className="text-sm font-mono truncate max-w-[200px]">{build.fileName}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">v{build.version}</Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {build.sizeBytes ? formatBytes(build.sizeBytes) : "—"}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {new Date(build.createdAt).toLocaleString("pt-BR")}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost" size="sm" className="h-7 gap-1 text-xs text-primary hover:text-primary"
                          onClick={() => window.open(build.s3Url, "_blank")}
                        >
                          <Download className="h-3.5 w-3.5" /> Baixar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
