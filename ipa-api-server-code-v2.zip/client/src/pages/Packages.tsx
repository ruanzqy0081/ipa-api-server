import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Box, Check, Copy, MoreVertical, Pause, Play, Plus, RefreshCw, Trash2, Zap } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

type PackageStatus = "active" | "paused" | "updating" | "deleted";

export default function Packages() {
  const utils = trpc.useUtils();
  const { data: packages, isLoading } = trpc.packages.list.useQuery();
  const createMut = trpc.packages.create.useMutation({ onSuccess: () => { utils.packages.list.invalidate(); toast.success("Package criado!"); setShowCreate(false); setForm({ name: "", version: "1.0.0", description: "" }); } });
  const updateMut = trpc.packages.update.useMutation({ onSuccess: () => { utils.packages.list.invalidate(); toast.success("Package atualizado!"); setEditPkg(null); } });
  const deleteMut = trpc.packages.delete.useMutation({ onSuccess: () => { utils.packages.list.invalidate(); toast.success("Package removido!"); } });
  const statusMut = trpc.packages.setStatus.useMutation({ onSuccess: () => { utils.packages.list.invalidate(); toast.success("Status atualizado!"); } });

  const [showCreate, setShowCreate] = useState(false);
  const [editPkg, setEditPkg] = useState<NonNullable<typeof packages>[0] | null>(null);
  const [form, setForm] = useState({ name: "", version: "1.0.0", description: "" });
  const [copiedToken, setCopiedToken] = useState<number | null>(null);

  const copyToken = (token: string, id: number) => {
    navigator.clipboard.writeText(token);
    setCopiedToken(id);
    setTimeout(() => setCopiedToken(null), 2000);
    toast.success("Token copiado!");
  };

  const statusLabel: Record<PackageStatus, string> = { active: "Ativo", paused: "Pausado", updating: "Atualizando", deleted: "Deletado" };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Packages</h1>
          <p className="text-sm text-muted-foreground mt-1">Gerencie seus packages de API Server</p>
        </div>
        <Button onClick={() => setShowCreate(true)} className="gap-2">
          <Plus className="h-4 w-4" /> Novo Package
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="border-border/50 bg-card/50 animate-pulse">
              <CardContent className="p-5 h-40" />
            </Card>
          ))}
        </div>
      ) : !packages?.length ? (
        <Card className="border-border/50 bg-card/50">
          <CardContent className="flex flex-col items-center justify-center py-16 gap-4">
            <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Box className="h-8 w-8 text-primary" />
            </div>
            <div className="text-center">
              <p className="font-semibold">Nenhum package criado</p>
              <p className="text-sm text-muted-foreground mt-1">Crie seu primeiro package para começar</p>
            </div>
            <Button onClick={() => setShowCreate(true)} className="gap-2">
              <Plus className="h-4 w-4" /> Criar Package
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {packages.filter((p) => p.status !== "deleted").map((pkg) => (
            <Card key={pkg.id} className="card-hover border-border/50 bg-card/50 group">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-10 w-10 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
                      <Box className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-base truncate">{pkg.name}</CardTitle>
                      <p className="text-xs text-muted-foreground">v{pkg.version}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={`status-${pkg.status} text-xs`}>{statusLabel[pkg.status as PackageStatus]}</Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => { setEditPkg(pkg); }}>
                          <RefreshCw className="mr-2 h-4 w-4" /> Editar
                        </DropdownMenuItem>
                        {pkg.status === "active" && (
                          <DropdownMenuItem onClick={() => statusMut.mutate({ id: pkg.id, status: "paused" })}>
                            <Pause className="mr-2 h-4 w-4" /> Pausar
                          </DropdownMenuItem>
                        )}
                        {pkg.status === "paused" && (
                          <DropdownMenuItem onClick={() => statusMut.mutate({ id: pkg.id, status: "active" })}>
                            <Play className="mr-2 h-4 w-4" /> Ativar
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => statusMut.mutate({ id: pkg.id, status: "updating" })}>
                          <Zap className="mr-2 h-4 w-4" /> Modo Atualização
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => { if (confirm("Excluir este package?")) deleteMut.mutate({ id: pkg.id }); }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" /> Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                {pkg.description && (
                  <p className="text-xs text-muted-foreground line-clamp-2">{pkg.description}</p>
                )}
                <div className="bg-muted/30 rounded-lg p-2.5">
                  <p className="text-xs text-muted-foreground mb-1">Token</p>
                  <div className="flex items-center gap-2">
                    <code className="text-xs font-mono text-foreground flex-1 truncate">{pkg.token}</code>
                    <button
                      onClick={() => copyToken(pkg.token, pkg.id)}
                      className="h-6 w-6 flex items-center justify-center rounded hover:bg-accent transition-colors shrink-0"
                    >
                      {copiedToken === pkg.id ? (
                        <Check className="h-3.5 w-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="h-3.5 w-3.5 text-muted-foreground" />
                      )}
                    </button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Criado em {new Date(pkg.createdAt).toLocaleDateString("pt-BR")}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Box className="h-5 w-5 text-primary" /> Novo Package
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Nome *</Label>
              <Input placeholder="Meu Package" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Versão</Label>
              <Input placeholder="1.0.0" value={form.version} onChange={(e) => setForm({ ...form, version: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Descrição</Label>
              <Textarea placeholder="Descrição do package..." value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancelar</Button>
            <Button
              onClick={() => createMut.mutate(form)}
              disabled={!form.name || createMut.isPending}
              className="gap-2"
            >
              {createMut.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Criar Package
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      {editPkg && (
        <Dialog open={!!editPkg} onOpenChange={() => setEditPkg(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <RefreshCw className="h-5 w-5 text-primary" /> Editar Package
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label>Nome</Label>
                <Input value={editPkg.name} onChange={(e) => setEditPkg({ ...editPkg, name: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Versão</Label>
                <Input value={editPkg.version} onChange={(e) => setEditPkg({ ...editPkg, version: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Descrição</Label>
                <Textarea value={editPkg.description ?? ""} onChange={(e) => setEditPkg({ ...editPkg, description: e.target.value })} rows={3} />
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={editPkg.status} onValueChange={(v) => setEditPkg({ ...editPkg, status: v as PackageStatus })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Ativo</SelectItem>
                    <SelectItem value="paused">Pausado</SelectItem>
                    <SelectItem value="updating">Atualizando</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditPkg(null)}>Cancelar</Button>
              <Button
                onClick={() => updateMut.mutate({ id: editPkg.id, name: editPkg.name, version: editPkg.version, description: editPkg.description ?? undefined, status: editPkg.status as PackageStatus })}
                disabled={updateMut.isPending}
              >
                Salvar Alterações
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
