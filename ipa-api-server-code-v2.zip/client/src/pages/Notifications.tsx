import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { AlertTriangle, Bell, BellOff, Check, CheckCheck, Clock, Info, Key, Smartphone, Zap } from "lucide-react";
import { toast } from "sonner";

const TYPE_CONFIG: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  key_expiring: { icon: Key, color: "text-amber-400", label: "Key Expirando" },
  new_device: { icon: Smartphone, color: "text-blue-400", label: "Novo Device" },
  limit_reached: { icon: AlertTriangle, color: "text-red-400", label: "Limite Atingido" },
  package_update: { icon: Zap, color: "text-violet-400", label: "Package" },
  system: { icon: Info, color: "text-slate-400", label: "Sistema" },
};

export default function Notifications() {
  const utils = trpc.useUtils();
  const { data: notifications, isLoading } = trpc.notifications.list.useQuery();
  const markReadMut = trpc.notifications.markRead.useMutation({ onSuccess: () => utils.notifications.list.invalidate() });
  const markAllMut = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => { utils.notifications.list.invalidate(); utils.notifications.unreadCount.invalidate(); toast.success("Todas marcadas como lidas!"); },
  });

  const unread = notifications?.filter((n) => !n.read).length ?? 0;

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Notificações</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {unread > 0 ? `${unread} não lida(s)` : "Todas as notificações lidas"}
          </p>
        </div>
        {unread > 0 && (
          <Button variant="outline" onClick={() => markAllMut.mutate()} disabled={markAllMut.isPending} className="gap-2 text-sm">
            <CheckCheck className="h-4 w-4" /> Marcar todas como lidas
          </Button>
        )}
      </div>

      <Card className="border-border/50 bg-card/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Bell className="h-4 w-4 text-primary" />
            Todas as Notificações
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Carregando...</div>
          ) : !notifications?.length ? (
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              <div className="h-16 w-16 rounded-2xl bg-muted/30 flex items-center justify-center">
                <BellOff className="h-8 w-8 text-muted-foreground/50" />
              </div>
              <div className="text-center">
                <p className="font-semibold">Nenhuma notificação</p>
                <p className="text-sm text-muted-foreground mt-1">Você está em dia!</p>
              </div>
            </div>
          ) : (
            <div className="divide-y divide-border/30">
              {notifications.map((notif) => {
                const config = TYPE_CONFIG[notif.type] ?? TYPE_CONFIG.system;
                const Icon = config.icon;
                return (
                  <div
                    key={notif.id}
                    className={`flex items-start gap-4 p-4 transition-colors ${!notif.read ? "bg-primary/5" : "hover:bg-accent/20"}`}
                  >
                    <div className={`h-9 w-9 rounded-xl bg-muted/50 flex items-center justify-center shrink-0 mt-0.5`}>
                      <Icon className={`h-4.5 w-4.5 ${config.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 mb-0.5">
                            <p className="text-sm font-semibold">{notif.title}</p>
                            {!notif.read && <div className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />}
                          </div>
                          <p className="text-sm text-muted-foreground leading-relaxed">{notif.message}</p>
                          <div className="flex items-center gap-2 mt-1.5">
                            <Badge variant="outline" className="text-xs py-0">{config.label}</Badge>
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {new Date(notif.createdAt).toLocaleString("pt-BR")}
                            </span>
                          </div>
                        </div>
                        {!notif.read && (
                          <button
                            onClick={() => markReadMut.mutate({ id: notif.id })}
                            className="h-7 w-7 flex items-center justify-center rounded-lg hover:bg-accent transition-colors shrink-0"
                            title="Marcar como lida"
                          >
                            <Check className="h-3.5 w-3.5 text-muted-foreground" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
