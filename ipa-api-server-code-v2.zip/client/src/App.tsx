import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import DashboardLayout from "./components/DashboardLayout";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Packages from "./pages/Packages";
import Keys from "./pages/Keys";
import Devices from "./pages/Devices";
import DylibBuilder from "./pages/DylibBuilder";
import VipUsers from "./pages/VipUsers";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";
import LLMDocs from "./pages/LLMDocs";
import Login from "./pages/Login";
import Settings from "./pages/Settings";

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route>
        <DashboardLayout>
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/packages" component={Packages} />
            <Route path="/keys" component={Keys} />
            <Route path="/devices" component={Devices} />
            <Route path="/dylib" component={DylibBuilder} />
            <Route path="/vip-users" component={VipUsers} />
            <Route path="/profile" component={Profile} />
            <Route path="/notifications" component={Notifications} />
            <Route path="/docs" component={LLMDocs} />
            <Route path="/404" component={NotFound} />
            <Route path="/settings" component={Settings} />
            <Route component={NotFound} />
          </Switch>
        </DashboardLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
