CREATE TABLE `activity_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`action` varchar(128) NOT NULL,
	`details` text,
	`entityType` varchar(64),
	`entityId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `devices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`udid` varchar(128) NOT NULL,
	`name` varchar(128),
	`userId` int,
	`packageId` int,
	`status` enum('online','offline','banned') NOT NULL DEFAULT 'offline',
	`lastSeen` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `devices_id` PRIMARY KEY(`id`),
	CONSTRAINT `devices_udid_unique` UNIQUE(`udid`)
);
--> statement-breakpoint
CREATE TABLE `dylib_builds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`packageId` int NOT NULL,
	`ownerId` int NOT NULL,
	`fileName` varchar(256) NOT NULL,
	`s3Url` text NOT NULL,
	`s3Key` varchar(512) NOT NULL,
	`version` varchar(32) NOT NULL DEFAULT '1.0.0',
	`sizeBytes` bigint DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `dylib_builds_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `key_aliases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`alias` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `key_aliases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `keys` (
	`id` int AUTO_INCREMENT NOT NULL,
	`packageId` int NOT NULL,
	`ownerId` int NOT NULL,
	`keyValue` varchar(256) NOT NULL,
	`alias` varchar(64),
	`duration` enum('day','week','month','year') NOT NULL DEFAULT 'month',
	`status` enum('active','inactive','expired','revoked','paused') NOT NULL DEFAULT 'inactive',
	`activatedAt` timestamp,
	`expiresAt` timestamp,
	`deviceId` int,
	`note` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `keys_id` PRIMARY KEY(`id`),
	CONSTRAINT `keys_keyValue_unique` UNIQUE(`keyValue`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('key_expiring','new_device','limit_reached','package_update','system') NOT NULL,
	`title` varchar(256) NOT NULL,
	`message` text NOT NULL,
	`read` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `packages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`name` varchar(128) NOT NULL,
	`version` varchar(32) NOT NULL DEFAULT '1.0.0',
	`description` text,
	`token` varchar(128) NOT NULL,
	`status` enum('active','paused','updating','deleted') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `packages_id` PRIMARY KEY(`id`),
	CONSTRAINT `packages_token_unique` UNIQUE(`token`)
);
--> statement-breakpoint
CREATE TABLE `vip_users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`vipLevel` enum('vip1','vip2','vip3','vip4') NOT NULL DEFAULT 'vip1',
	`keyLimit` int NOT NULL DEFAULT 200,
	`dailyLimit` int NOT NULL DEFAULT 1000,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vip_users_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `username` varchar(64);--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;--> statement-breakpoint
ALTER TABLE `users` ADD `language` varchar(8) DEFAULT 'pt' NOT NULL;